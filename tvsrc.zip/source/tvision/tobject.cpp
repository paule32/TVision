/*------------------------------------------------------------*/
/* filename -       tobject.cpp                               */
/*                                                            */
/* function(s)                                                */
/*                  TObject member functions                  */
/*------------------------------------------------------------*/
/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *
 */

#define Uses_TObject
#include <tvision/tv.h>

void TObject::shutDown()
{
}
