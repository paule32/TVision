/*------------------------------------------------------------*/
/* filename -       nmstrcol.cpp                              */
/*                                                            */
/* defines the streamable name for class TStringCollection    */
/*------------------------------------------------------------*/
/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *
 */

#define Uses_TStringCollection
#include <tvision/tv.h>

const char * const _NEAR TStringCollection::name = "TStringCollection";
