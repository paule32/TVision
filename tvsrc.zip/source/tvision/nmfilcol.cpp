/*------------------------------------------------------------*/
/* filename -       nmfilcol.cpp                              */
/*                                                            */
/* defines the streamable name for class TFileCollection      */
/*------------------------------------------------------------*/
/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *
 */

#define Uses_TFileCollection
#include <tvision/tv.h>

const char * const _NEAR TFileCollection::name = "TFileCollection";
